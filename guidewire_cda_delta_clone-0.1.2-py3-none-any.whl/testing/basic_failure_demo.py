#!/usr/bin/env python3
"""
Basic script to demonstrate transaction failures with simple progress output.

This script shows how transaction failures appear in progress monitoring
without relying on complex display methods.
"""

import os
from pathlib import Path
import sys
import time
from datetime import datetime

# Add the guidewire package to the path
repo_root = Path(__file__).parent.parent
sys.path.insert(0, str(repo_root))

from guidewire.progress_managers import SimpleProgressManager


def demo_transaction_failures():
    """Demonstrate various transaction failure scenarios with live progress display."""
    print("🚀 Transaction Failure Demonstrations")
    print("=" * 60)
    print(f"Timestamp: {datetime.now().isoformat()}")
    print("\nThis demo will show live progress tables with transaction failures...")
    
    # Demo 1: Early failure
    print("\n🔥 Demo 1: Early Transaction Failure")
    print("-" * 40)
    
    progress_manager = SimpleProgressManager(show_progress=True, refresh_per_second=2.0)
    table_name = "policy_holders"
    total_folders = 5
    
    # Start the progress manager and table
    progress_manager.start([table_name])
    progress_manager.start_table(table_name, total_folders)
    print(f"✅ Started processing {table_name} with {total_folders} folders")
    time.sleep(2)  # Let user see the initial state
    
    try:
        # Process one folder successfully
        progress_manager.update_progress(table_name, 1, total_folders, "Processing folder 1680350543000...")
        print("✅ Processed folder 1 successfully")
        time.sleep(2)
        
        # Fail on second folder
        print("💥 Transaction failed on folder 2!")
        progress_manager.complete_table(table_name, "Schema validation failed: Incompatible column type change detected")
        time.sleep(3)  # Let user see the error state
        
    finally:
        progress_manager.stop()
    
    
    # Demo 2: Late failure after partial success
    print("\n🔥 Demo 2: Late Transaction Failure (Partial Success)")
    print("-" * 40)
    
    progress_manager = SimpleProgressManager(show_progress=True, refresh_per_second=2.0)
    table_name = "claims_data"
    total_folders = 4
    
    progress_manager.start([table_name])
    progress_manager.start_table(table_name, total_folders)
    print(f"✅ Started processing {table_name} with {total_folders} folders")
    time.sleep(1)
    
    try:
        # Process 3 folders successfully
        for i in range(1, 4):
            progress_manager.update_progress(table_name, i, total_folders, f"Processing folder {1680000000000 + i * 100000}...")
            print(f"✅ Processed folder {i} successfully")
            time.sleep(1.5)
        
        # Fail during final commit
        print("💥 Final transaction commit failed!")
        progress_manager.complete_table(table_name, "Commit failed: Concurrent modification detected during transaction log write")
        time.sleep(3)
        
    finally:
        progress_manager.stop()
    
    # Demo 3: Storage permission failure
    print("\n🔥 Demo 3: Storage Permission Failure")
    print("-" * 40)
    
    progress_manager = SimpleProgressManager(show_progress=True, refresh_per_second=2.0)
    table_name = "user_profiles"
    total_folders = 3
    
    progress_manager.start([table_name])
    progress_manager.start_table(table_name, total_folders)
    print(f"✅ Started processing {table_name} with {total_folders} folders")
    time.sleep(1)
    
    try:
        # Immediate failure
        progress_manager.update_progress(table_name, 0, total_folders, "Connecting to storage...")
        print("🔗 Attempting to connect to storage...")
        time.sleep(3)  # Simulate connection timeout
        
        print("💥 Storage connection failed!")
        progress_manager.complete_table(table_name, "Access denied: Invalid storage account credentials or insufficient permissions")
        time.sleep(3)
        
    finally:
        progress_manager.stop()

    # Demo 4: Multiple tables with mixed results
    print("\n🔥 Demo 4: Multiple Tables with Mixed Results")
    print("-" * 40)
    
    tables = [
        ("products", 2, True),      # Success
        ("orders", 4, False),       # Failure 
        ("customers", 3, True),     # Success
        ("inventory", 5, False)     # Failure
    ]
    
    progress_manager = SimpleProgressManager(show_progress=True, refresh_per_second=2.0)
    table_names = [table[0] for table in tables]
    
    # Start all tables at once
    progress_manager.start(table_names)
    for table_name, total_folders, _ in tables:
        progress_manager.start_table(table_name, total_folders)
        print(f"✅ Started {table_name} ({total_folders} folders)")
    
    time.sleep(2)  # Let user see all tables started
    
    try:
        # Process each table
        for table_name, total_folders, will_succeed in tables:
            print(f"\n🎯 Processing {table_name}...")
            
            if will_succeed:
                # Process all folders successfully
                for i in range(1, total_folders + 1):
                    progress_manager.update_progress(table_name, i, total_folders, f"Processing folder {i}...")
                    time.sleep(0.8)
                
                progress_manager.complete_table(table_name)
                print(f"✅ {table_name} completed successfully")
                
            else:
                # Process some folders then fail
                folders_before_fail = max(1, total_folders // 2)
                for i in range(1, folders_before_fail + 1):
                    progress_manager.update_progress(table_name, i, total_folders, f"Processing folder {i}...")
                    time.sleep(0.6)
                
                print(f"💥 {table_name} failed!")
                progress_manager.complete_table(table_name, f"Transaction failed in {table_name}: Data corruption detected")
            
            time.sleep(1)  # Brief pause between tables
        
        print("\n🏁 All tables processed! Final state displayed for 5 seconds...")
        time.sleep(5)
        
    finally:
        progress_manager.stop()
    
    print("\n📋 All demonstrations completed!")
    print("=" * 60)


if __name__ == "__main__":
    try:
        demo_transaction_failures()
    except KeyboardInterrupt:
        print("\n⚠️  Demo interrupted by user")
    except Exception as e:
        print(f"\n❌ Demo failed with error: {e}")
